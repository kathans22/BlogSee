<?php 
$conn = mysqli_connect("localhost","root","","test") or die("connection failed");
?>